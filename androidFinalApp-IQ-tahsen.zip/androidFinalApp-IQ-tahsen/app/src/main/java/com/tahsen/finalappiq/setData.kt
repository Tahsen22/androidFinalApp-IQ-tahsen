package com.tahsen.finalappiq

object setData {

    const val name:String="name"
    const val score:String="score"

    fun getQuestion():ArrayList<Questiondata>{
        var que:ArrayList<Questiondata> = arrayListOf()

        var question1 = Questiondata(
            id = 1,
            question = "What is the capital city of Canada?",
            option_one = "Toronto",
            option_two = "Ottawa",
            option_three = "Regina",
            option_four = "Vancouver",
            correct_answer = 2
        )
        var question2 = Questiondata(
            id = 2,
            question = "What is the largest province in Canada?",
            option_one = "Ontario",
            option_two = "Quebec",
            option_three = "Alberta",
            option_four = "Winnipeg",
            correct_answer = 2
        )
        var question3 = Questiondata(
            id = 3,
            question = "What is the coldest province in Canada?",
            option_one = "Ontario",
            option_two = "Quebec",
            option_three = "Nunavut",
            option_four = "Winnipeg",
            correct_answer = 3
        )
        var question4 = Questiondata(
            id = 4,
            question = "Who is the first prime minister of Canada?",
            option_one = "John A. Macdonald",
            option_two = "Alexander Mackenzie",
            option_three = "Joe Clark",
            option_four = "Mackenzie King",
            correct_answer = 1
        )
        var question5 = Questiondata(
            id = 5,
            question = "When are Canadians celebrating the Canada Day?",
            option_one = "February 21st",
            option_two = "June 1st",
            option_three = "January 1st",
            option_four = "July 1st",
            correct_answer = 4
        )

        que.add(question1)
        que.add(question2)
        que.add(question3)
        que.add(question4)
        que.add(question5)
        return que
    }
}